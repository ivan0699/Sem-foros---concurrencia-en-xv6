#include "types.h"
#include "user.h"
#include "semaphore.h"

#define SEM_PING 2
#define SEM_PONG 3

int
main(int args, char *argv[])
{
   if (sem_open(SEM_PING, SEM_OPEN_OR_CREATE, 1) == -1 || sem_open(SEM_PONG, SEM_OPEN_OR_CREATE, 0) == -1 ){
   //setea el valor de los flag, en otras palabras
   //sem_open (SEM_PING = 2, SEM_OPEN_OR_CREATE = 2, y el tercero valor puede ser cualquier numero >= a 0 o < -1
   //pero tambien tienen que ser distintos de uno al otro)
   //ahora esto compara cada valor de sem_open(en este caso son 2,2,1) con -1, como esto no pasa entonces entra al fork
  	
  	printf(1, "La barrera no esta activa\n");
  	//devuelve un error si alguna de las tres banderas es igual a -1.
   
   }else{
  	int n = atoi(argv[1]);
  	//La función atoi () en lenguaje C convierte el tipo de datos de cadena al tipo de datos entero.
  	
  	printf(1, "Rebotar %d veces.\n",n);
  	//devuelve la cantidad de veces que se ejecuta ping y pong.
  	
  	
  	if (fork() == 0) //proceso hijo
  	//fork: genera un duplicado del proceso actual, Retorna al proceso padre el identificador del proceso hijo y retorna 0 al hijo. 
  	//este fork() == 0, este hace que si el == no esta, este se queda zombie y no deja ejecutar otro proceso.   
    {
      for (int i = 0; i < n; ++i)
      {
    	sem_down(SEM_PONG);
    	//mando a dormir al hijo
      
      printf(1, "PONG #%d\n",i);
      
    	sem_up(SEM_PING);
    	//desperto al padre
      }
      if (sem_close(SEM_PONG) == 0)
        sem_close(SEM_PONG);
    }
    else           
    // proceso padre, inicializa el proceso padre y despues ejecuta el proceso hijo.
    {
      for (int j = 0; j < n; ++j)
      {
    	sem_down(SEM_PING);
    	//mando a dormir al padre
    	
      printf(1, "PING #%d\n",j);
      	
    	sem_up(SEM_PONG);
    	//desperto al hijo
      }
      if(sem_close(SEM_PING) == 0)
         sem_close(SEM_PING);
      wait(); 
      //Una llamada a wait () bloquea el proceso de llamada hasta que uno de sus
      //procesos secundarios sale o se recibe una señal. Después de que finaliza
      // el proceso hijo, el padre continúa su ejecución después de esperar la 
      //instrucción de llamada al sistema. 
    }
  }
  exit();
}

