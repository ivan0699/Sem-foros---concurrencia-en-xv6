#include "spinlock.h"
#define SEM_CREATE 0
#define SEM_OPEN 1
#define SEM_OPEN_OR_CREATE 2
#define MAX_SEMAPHORE 10
#define TRUE 1
#define FALSE 0


struct _semaphore {
  int value;
  int open;
  int cproc;
  int created;
  struct spinlock lock;
};

typedef struct _semaphore  semaphore_t;

semaphore_t semaphor[MAX_SEMAPHORE];

