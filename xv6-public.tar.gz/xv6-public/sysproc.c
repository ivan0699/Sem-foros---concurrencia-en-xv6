#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "semaphore.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}



int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}


int
sys_sem_open(void)
{
    
  int semaphore;
  argint(0, &semaphore); //control argint no -1
  int flags;
  argint(1, &flags);
  int value;
  argint(2,&value); //control argint no -1
    
  if(semaphore < 0 || MAX_SEMAPHORE <= semaphore || value < 0 || flags < 0 || argint(0, &semaphore) < 0 || argint(1, &flags) < 0 || argint(2,&value) < 0){
    
  return -1;
  }
     
//     Si el semáforo semaphore no existe, lo crea inicializado al valor value y retorna 0. Si el semáforo está creado, entonces se produce un error y la función devuelve -1.
    
  if(flags == SEM_CREATE){       
    if(semaphor[semaphore].created == TRUE ){                  
      return -1;              
              }
    
    acquire(&semaphor[semaphore].lock);
    semaphor[semaphore].value = value;
    semaphor[semaphore].open = FALSE;
    semaphor[semaphore].cproc = 0;
    semaphor[semaphore].created = TRUE;
    release(&semaphor[semaphore].lock);
  return 0;
  }  
    
//Abre el semáforo semaphore. Si el mismo no existe, esto será considerado un error y la función devuelve -1. 
  if(flags == SEM_OPEN){
    if(semaphor[semaphore].created == TRUE ){                       
         acquire(&semaphor[semaphore].lock);
         semaphor[semaphore].cproc += 1;
         semaphor[semaphore].open = TRUE;
         release(&semaphor[semaphore].lock);
        
        return 0;
    }         
                 
    return -1;

  }
        
//Abre el semáforo semaphore para usarlo. Si el mismo no existe, lo crea inicializando al valor value. En ambos casos retorna 0.
    
  if(flags == SEM_OPEN_OR_CREATE){        
    if(semaphor[semaphore].created == TRUE){                  
      acquire(&semaphor[semaphore].lock);
      semaphor[semaphore].cproc += 1;
      semaphor[semaphore].open = TRUE;
      release(&semaphor[semaphore].lock);            
      return 0;
    }          
    acquire(&semaphor[semaphore].lock);        
    semaphor[semaphore].value = value;
    semaphor[semaphore].open = FALSE;
    semaphor[semaphore].cproc = 0;
    semaphor[semaphore].created = TRUE;
    release(&semaphor[semaphore].lock);
    return 0;
  }
  return -1;    
}

// Cierra el uso del semáforo con nombre semaphore. Sí ningún otro proceso lo está usando, semaphore queda liberado para volver a ser usado. Si semaphore no existe esto será considerado un error. En caso de éxito devuelve ‘n’ con n la cantidad de procesos que están usando todavía el semáforo (notar que la función devuelva 0 implica que el semáforo está libre para volver a ser usado). En caso de error la función devuelve -1.
int
sys_sem_close(void)
{    
  int semaphore;
  if(argint(0, &semaphore) < 0 || semaphore < 0 || semaphore > MAX_SEMAPHORE){       //fijarse la devolucion
    return -1;
  }
  
  
  if(semaphor[semaphore].created != TRUE){            
    return -1;
  }
      
      
  if(semaphor[semaphore].cproc == 1){
    acquire(&semaphor[semaphore].lock);
    semaphor[semaphore].cproc -= 1;
    semaphor[semaphore].open = FALSE;
    semaphor[semaphore].created = FALSE;
    
    
  } else {
      acquire(&semaphor[semaphore].lock);
      semaphor[semaphore].cproc -= 1;
}
      
  release(&semaphor[semaphore].lock);

  return semaphor[semaphore].cproc;
}
    
// Incrementa (destraba) el semáforo con nombre semaphore. Si semaphore no existe esto será considerado un error. En caso de éxito devuelve 0 y en caso de error -1.
int
sys_sem_up(void)
{
  int semaphore;
  if(argint(0, &semaphore) < 0 || semaphore < 0 || MAX_SEMAPHORE <= semaphore){
    return -1;
  }

  acquire(&semaphor[semaphore].lock);
  
  wakeup(&semaphor[semaphore]);  
  semaphor[semaphore].value += 1;
  release(&semaphor[semaphore].lock);
  return 0;
//     }
//     return -1;
}
//Decrementa (traba) el semáforo con nombre semaphore. Si semaphore no existe esto será considerado un error.  En caso de éxito devuelve 0 y en caso de error -1.
int
sys_sem_down(void)
{
int semaphore;

  if(argint(0, &semaphore) < 0 || semaphore < 0 || semaphore > MAX_SEMAPHORE){
    return -1;
  }
//   if(semaphor[semaphore]->name == semaphore){
  acquire(&semaphor[semaphore].lock);
  while(semaphor[semaphore].value == 0){
    sleep(&semaphor[semaphore], &semaphor[semaphore].lock);
  } 
   if(semaphor[semaphore].value > 0){
    semaphor[semaphore].value -= 1;
  }
  release(&semaphor[semaphore].lock);

  return 0;
//   }
//   return -1;
}
// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
